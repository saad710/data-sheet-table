import React from 'react';

const WorksBoardTable = () => {
    return (
        <div>
              {/* <div className="container-fluid mt-110">
                    <div className="row">
                        <div className="col-sm-12">
                            <div className="card">
                            <div className="card-body"> */}
                                <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col" colSpan='1'></th>
                                        <th scope="col" colSpan='1'>A</th>
                                        <th scope="col" colSpan='1'>B</th>
                                        <th scope="col" colSpan='1'>C</th>
                                        <th scope="col" colSpan='1'>D</th>
                                        <th scope="col" colSpan='1'>E</th>
                                        <th scope="col" colSpan='1'>F</th>
                                        <th scope="col" colSpan='1'>G</th>
                                        <th scope="col" colSpan='1'>H</th>
                                        <th scope="col" colSpan='1'>I</th>
                                        <th scope="col" colSpan='1'>J</th>
                                        <th scope="col" colSpan='1'>K</th>
                                        <th scope="col" colSpan='1'>L</th>
                                        <th scope="col" colSpan='1'>M</th>
                                        <th scope="col" colSpan='1'>N</th>
                                        <th scope="col" colSpan='1'>O</th>
                                        <th scope="col" colSpan='1'>P</th>
                                        <th scope="col" colSpan='1'>Q</th>
                                        <th scope="col" colSpan='1'>R</th>
                                        <th scope="col" colSpan='1'>S</th>
                                        <th scope="col" colSpan='1'>T</th>
                                        <th scope="col" colSpan='1'>U</th>
                                        <th scope="col" colSpan='1'>V</th>
                                        <th scope="col" colSpan='1'>W</th>
                                        <th scope="col" colSpan='1'>X</th>
                                        <th scope="col" colSpan='1'>Y</th>
                                        <th scope="col" colSpan='1'>Z</th>
                                        <th scope="col" colSpan='1'>AA</th>
                                     
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        {/* <th scope="row">05</th> */}
                                        <td colSpan='1'>1</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}></td>
                                        <td colSpan='5'>Wk Bg 08/03/2015</td>
                                        <td colSpan='1'></td>
                                        <td colSpan='1'></td>
                                        <td colSpan='5'>Wk Bg 08/03/2015</td>
                                        <td colSpan='1'></td>
                                        <td colSpan='1'></td>
                                        <td colSpan='5'>Wk Bg 08/03/2015</td>
                                        <td colSpan='1'></td>
                                        <td colSpan='1'></td>
                                        <td colSpan='5'>Wk Bg 08/03/2015</td>

                                    </tr>
                                    <tr>
                                        {/* <th scope="row">05</th> */}
                                        <td colSpan='1'>2</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Painters</td>
                                        <td colSpan='1'>Mo</td>
                                        <td colSpan='1'>Tu</td>
                                        <td colSpan='1'>We</td>
                                        <td colSpan='1'>Th</td>
                                        <td colSpan='1'>Fr</td>
                                        <td colSpan='1' style={{backgroundColor:"silver"}}>Sa</td>
                                        <td colSpan='1' style={{backgroundColor:"silver"}}>Su</td>
                                        <td colSpan='1'>Mo</td>
                                        <td colSpan='1'>Tu</td>
                                        <td colSpan='1'>We</td>
                                        <td colSpan='1'>Th</td>
                                        <td colSpan='1'>Fr</td>
                                        <td colSpan='1' style={{backgroundColor:"silver"}}>Sa</td>
                                        <td colSpan='1' style={{backgroundColor:"silver"}}>Su</td>
                                        <td colSpan='1'>Mo</td>
                                        <td colSpan='1'>Tu</td>
                                        <td colSpan='1'>We</td>
                                        <td colSpan='1'>Th</td>
                                        <td colSpan='1'>Fr</td>
                                        <td colSpan='1' style={{backgroundColor:"silver"}}>Sa</td>
                                        <td colSpan='1' style={{backgroundColor:"silver"}}>Su</td>
                                        <td colSpan='1'>Mo</td>
                                        <td colSpan='1'>Tu</td>
                                        <td colSpan='1'>We</td>
                                        <td colSpan='1'>Th</td>
                                        <td colSpan='1'>Fr</td>
                                    </tr>
                                    <tr>
                                        <td colSpan='1'>3</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Donny G</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='2'>Rosary Homes</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='3' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='2' style={{fontSize:"8px"}}>Wintringham Homes</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='2' style={{fontSize:"8px"}}>Gilguniyah</td>
                                        <td colSpan='2' >Thornbury PS</td>
                                        <td colSpan='1' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                    </tr>
                                    
                                    <tr>
                                        <td colSpan='1'>4</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Troy Kennedy</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='3' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='5' >Latorbe Uni</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        
                                    </tr>

                                    <tr>
                                        <td colSpan='1'>5</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Cristine R</td>
                                        <td colSpan='5' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='3' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='2' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' > Latorbe Uni</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        
                                    </tr>
                                    <tr>
                                        <td colSpan='1'>6</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Leigh G</td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                    </tr>
                                    <tr>
                                        <td colSpan='1'>7</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Donny G</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='2'>Rosary Homes</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='3' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='2' style={{fontSize:"8px"}}>Wintringham Homes</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='2' style={{fontSize:"8px"}}>Gilguniyah</td>
                                        <td colSpan='2' >Thornbury PS</td>
                                        <td colSpan='1' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                    </tr>
                                    
                                    <tr>
                                        <td colSpan='1'>8</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Troy Kennedy</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='3' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='5' >Latorbe Uni</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        
                                    </tr>

                                    <tr>
                                        <td colSpan='1'>9</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Cristine R</td>
                                        <td colSpan='5' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='3' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='2' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' > Latorbe Uni</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        
                                    </tr>
                                    <tr>
                                        <td colSpan='1'>10</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Leigh G</td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                    </tr>
                                    <tr>
                                        <td colSpan='1'>11</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Donny G</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='2'>Rosary Homes</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='3' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='2' style={{fontSize:"8px"}}>Wintringham Homes</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='2' style={{fontSize:"8px"}}>Gilguniyah</td>
                                        <td colSpan='2' >Thornbury PS</td>
                                        <td colSpan='1' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                    </tr>
                                    
                                    <tr>
                                        <td colSpan='1'>12</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Troy Kennedy</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"8px"}}>chesco biyard</td>
                                        <td colSpan='3' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>chesco biyard</td>
                                        <td colSpan='5' >Latorbe Uni</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        
                                    </tr>

                                    <tr>
                                        <td colSpan='1'>13</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Cristine R</td>
                                        <td colSpan='5' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='3' style={{backgroundColor:"red"}}></td>
                                        <td colSpan='2' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' > Latorbe Uni</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        
                                    </tr>
                                    <tr>
                                        <td colSpan='1'>14</td>
                                        <td colSpan='1' style={{backgroundColor:"#85C285"}}>Leigh G</td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='5' >Thornbury PS</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}>stive wizard</td>
                                        <td colSpan='1' style={{fontSize:"4px",backgroundColor:"silver"}}></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                        <td colSpan='1' ></td>
                                    </tr>

                                </tbody>
                                </table>
                            {/* </div> */}
                {/* //             </div> */}
                {/* //         </div> */}
                {/* //     </div> */}
                {/* // </div> */}
            
        </div>
    );
};

export default WorksBoardTable;